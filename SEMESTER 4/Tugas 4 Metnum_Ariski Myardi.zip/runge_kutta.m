function [t, y] = runge_kutta(f, tspan, y0, h)
    % Inisialisasi variabel
    t0 = tspan(1);
    tf = tspan(2);
    t = t0:h:tf;
    N = length(t);
    y = zeros(size(t));
    y(1) = y0;

    % Metode Runge-Kutta orde 3
    for i = 1:N-1
        % Langkah iterasi RK3
        k1 = h * f(t(i), y(i));
        k2 = h * f(t(i) + h/2, y(i) + k1/2);
        k3 = h * f(t(i) + h, y(i) - k1 + 2*k2);

        y(i+1) = y(i) + (k1 + 4*k2 + k3) / 6;
    end
end

% Contoh penggunaan:
% Definisi fungsi yang akan diintegrasikan (contoh: dy/dt = -y + t)
f = @(t, y) -y + t;
% Rentang waktu
tspan = [0, 5];
% Kondisi awal
y0 = 1;
% Panjang langkah waktu (step size)
h = 0.1;

% Panggil fungsi Runge-Kutta orde 3
[t, y] = runge_kutta_3(f, tspan, y0, h);

% Plot hasil
plot(t, y, '-o');
xlabel('t');
ylabel('y(t)');
title('Solusi numerik menggunakan Runge-Kutta orde 3');
grid on;

